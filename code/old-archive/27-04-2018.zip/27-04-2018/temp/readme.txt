In this folder the program will store temporary files.
